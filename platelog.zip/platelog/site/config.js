/* Supabase connection for Plate Log. The publishable key is designed to be public.
   NEVER put the secret / service_role key in this file. */
window.PLATELOG_CONFIG={
  SUPABASE_URL:'https://xrkgqrappikbxtyoydot.supabase.co',
  SUPABASE_ANON_KEY:'sb_publishable_J7WAbUz2xPSuwkUQXmLsJQ_dcTOYNPX'
};
